from datetime import datetime
from pydantic import BaseModel, Field


class TaskCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=100)
    description: str
    deadline: datetime
    estimated_hours: float = Field(..., gt=0)
    priority: int = Field(..., ge=1, le=5)
    owner_id: str
    status: str = "pending"
    created_at: datetime
    completed_at: datetime | None = None


class TaskResponse(TaskCreate):
    id: str