from fastapi import APIRouter, HTTPException
from fastapi import Depends
from app.auth.dependencies import get_current_user

from app.schemas.task_schema import TaskCreate
from app.services.task_service import (
    create_task,
    get_all_tasks,
    get_task,
    update_task,
    delete_task
)

router = APIRouter(
    prefix="/tasks",
    tags=["Tasks"]
)


@router.post("/")
async def create_task(
    task: TaskCreate,
    current_user=Depends(get_current_user)
):
    return await create_task(task, current_user)

@router.get("/")
async def fetch_tasks(
    current_user=Depends(get_current_user)):
    return await get_all_tasks(current_user)


@router.get("/{task_id}")
async def fetch_task(task_id: str,current_user=Depends(get_current_user)):
    task = await get_task(task_id,current_user)

    if not task:
        raise HTTPException(
            status_code=404,
            detail="Task not found"
        )

    return task


@router.put("/{task_id}")
async def edit_task(task_id: str, task: TaskCreate,current_user=Depends(get_current_user)):
    updated_task = await update_task(task_id, task,current_user)

    if not updated_task:
        raise HTTPException(
            status_code=404,
            detail="Task not found"
        )

    return await updated_task


@router.delete("/{task_id}")
async def remove_task(task_id: str,current_user=Depends(get_current_user)):
    deleted = await delete_task(task_id,current_user)

    if deleted == 0:
        raise HTTPException(
            status_code=404,
            detail="Task not found"
        )

    return {
        "message": "Task deleted successfully"
    }

from app.services.task_service import create_task as create_task_service

@router.post("/")
async def create_task(
    task: TaskCreate,
    current_user=Depends(get_current_user)
):
    return await create_task_service(task, current_user)